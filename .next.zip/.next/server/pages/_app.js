/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material/styles */ \"@mui/material/styles\");\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/x-date-pickers/AdapterDayjs */ \"@mui/x-date-pickers/AdapterDayjs\");\n/* harmony import */ var _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _vercel_analytics_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @vercel/analytics/react */ \"@vercel/analytics/react\");\n/* harmony import */ var _styles_global_theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../styles/global.theme */ \"./src/styles/global.theme.ts\");\n/* harmony import */ var _mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/x-date-pickers */ \"@mui/x-date-pickers\");\n/* harmony import */ var _mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_3__]);\n_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\nvar _jsxFileName = \"D:\\\\resume builder\\\\resume-builder\\\\resume-builder\\\\src\\\\pages\\\\_app.tsx\";\n\nfunction ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }\n\nfunction _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }\n\nfunction _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }\n\n\n\n // eslint-disable-next-line import/no-unresolved\n\n\n\n\n\n\nfunction MyApp({\n  Component,\n  pageProps\n}) {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.StyledEngineProvider, {\n    injectFirst: true,\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.ThemeProvider, {\n      theme: _styles_global_theme__WEBPACK_IMPORTED_MODULE_4__.GLOBAL_MUI_THEME,\n      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_5__.LocalizationProvider, {\n        dateAdapter: _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_2__.AdapterDayjs,\n        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Component, _objectSpread({}, pageProps), void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 17,\n          columnNumber: 11\n        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_3__.Analytics, {}, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 18,\n          columnNumber: 11\n        }, this)]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 16,\n        columnNumber: 9\n      }, this)\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 15,\n      columnNumber: 7\n    }, this)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 14,\n    columnNumber: 5\n  }, this);\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQTtDQUdBOztBQUNBO0FBRUE7QUFDQTs7O0FBRUEsU0FBU00sS0FBVCxDQUFlO0VBQUVDLFNBQUY7RUFBYUM7QUFBYixDQUFmLEVBQW1EO0VBQ2pELG9CQUNFLDhEQUFDLHNFQUFEO0lBQXNCLFdBQVcsTUFBakM7SUFBQSx1QkFDRSw4REFBQywrREFBRDtNQUFlLEtBQUssRUFBRUosa0VBQXRCO01BQUEsdUJBQ0UsOERBQUMscUVBQUQ7UUFBc0IsV0FBVyxFQUFFRiwwRUFBbkM7UUFBQSx3QkFDRSw4REFBQyxTQUFELG9CQUFlTSxTQUFmO1VBQUE7VUFBQTtVQUFBO1FBQUEsUUFERixlQUVFLDhEQUFDLDhEQUFEO1VBQUE7VUFBQTtVQUFBO1FBQUEsUUFGRjtNQUFBO1FBQUE7UUFBQTtRQUFBO01BQUE7SUFERjtNQUFBO01BQUE7TUFBQTtJQUFBO0VBREY7SUFBQTtJQUFBO0lBQUE7RUFBQSxRQURGO0FBVUQ7O0FBRUQsaUVBQWVGLEtBQWYsRSIsInNvdXJjZXMiOlsid2VicGFjazovL3Jlc3VtZS1idWlsZGVyLy4vc3JjL3BhZ2VzL19hcHAudHN4P2Y5ZDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xuXG5pbXBvcnQgeyBTdHlsZWRFbmdpbmVQcm92aWRlciwgVGhlbWVQcm92aWRlciB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwvc3R5bGVzJztcblxuaW1wb3J0IHsgQWRhcHRlckRheWpzIH0gZnJvbSAnQG11aS94LWRhdGUtcGlja2Vycy9BZGFwdGVyRGF5anMnO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGltcG9ydC9uby11bnJlc29sdmVkXG5pbXBvcnQgeyBBbmFseXRpY3MgfSBmcm9tICdAdmVyY2VsL2FuYWx5dGljcy9yZWFjdCc7XG5pbXBvcnQgdHlwZSB7IEFwcFByb3BzIH0gZnJvbSAnbmV4dC9hcHAnO1xuaW1wb3J0IHsgR0xPQkFMX01VSV9USEVNRSB9IGZyb20gJy4uL3N0eWxlcy9nbG9iYWwudGhlbWUnO1xuaW1wb3J0IHsgTG9jYWxpemF0aW9uUHJvdmlkZXIgfSBmcm9tICdAbXVpL3gtZGF0ZS1waWNrZXJzJztcblxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxTdHlsZWRFbmdpbmVQcm92aWRlciBpbmplY3RGaXJzdD5cbiAgICAgIDxUaGVtZVByb3ZpZGVyIHRoZW1lPXtHTE9CQUxfTVVJX1RIRU1FfT5cbiAgICAgICAgPExvY2FsaXphdGlvblByb3ZpZGVyIGRhdGVBZGFwdGVyPXtBZGFwdGVyRGF5anN9PlxuICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgICA8QW5hbHl0aWNzIC8+XG4gICAgICAgIDwvTG9jYWxpemF0aW9uUHJvdmlkZXI+XG4gICAgICA8L1RoZW1lUHJvdmlkZXI+XG4gICAgPC9TdHlsZWRFbmdpbmVQcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXlBcHA7XG4iXSwibmFtZXMiOlsiU3R5bGVkRW5naW5lUHJvdmlkZXIiLCJUaGVtZVByb3ZpZGVyIiwiQWRhcHRlckRheWpzIiwiQW5hbHl0aWNzIiwiR0xPQkFMX01VSV9USEVNRSIsIkxvY2FsaXphdGlvblByb3ZpZGVyIiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./src/styles/global.theme.ts":
/*!************************************!*\
  !*** ./src/styles/global.theme.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"GLOBAL_MUI_THEME\": () => (/* binding */ GLOBAL_MUI_THEME)\n/* harmony export */ });\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/material/styles */ \"@mui/material/styles\");\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);\n\nconst GLOBAL_MUI_THEME = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.createTheme)({\n  palette: {\n    resume: {\n      50: '#E7EEFA',\n      100: '#C7D6E4',\n      200: '#A8B9CC',\n      300: '#889DB3',\n      400: '#7188A1',\n      500: '#59748F',\n      600: '#4C667E',\n      700: '#3C5268',\n      800: '#2E4052',\n      900: '#1C2C3A'\n    },\n    primary: {\n      main: '#2E4052'\n    }\n  },\n  components: {\n    MuiSwitch: {\n      styleOverrides: {\n        switchBase: {\n          '& > .MuiSwitch-thumb': {\n            backgroundColor: '#FFFFFF'\n          },\n          '&.Mui-checked > .MuiSwitch-thumb': {\n            backgroundColor: '#59748F' // resume 500 variant\n\n          },\n          '& + .MuiSwitch-track': {\n            backgroundColor: '#C7D6E4' // resume 100 variant\n\n          },\n          '&.Mui-checked + .MuiSwitch-track': {\n            backgroundColor: '#C7D6E4' // resume 100 variant\n\n          }\n        }\n      }\n    }\n  }\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc3R5bGVzL2dsb2JhbC50aGVtZS50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUVPLE1BQU1DLGdCQUFnQixHQUFHRCxpRUFBVyxDQUFDO0VBQzFDRSxPQUFPLEVBQUU7SUFDUEMsTUFBTSxFQUFFO01BQ04sSUFBSSxTQURFO01BRU4sS0FBSyxTQUZDO01BR04sS0FBSyxTQUhDO01BSU4sS0FBSyxTQUpDO01BS04sS0FBSyxTQUxDO01BTU4sS0FBSyxTQU5DO01BT04sS0FBSyxTQVBDO01BUU4sS0FBSyxTQVJDO01BU04sS0FBSyxTQVRDO01BVU4sS0FBSztJQVZDLENBREQ7SUFhUEMsT0FBTyxFQUFFO01BQ1BDLElBQUksRUFBRTtJQURDO0VBYkYsQ0FEaUM7RUFrQjFDQyxVQUFVLEVBQUU7SUFDVkMsU0FBUyxFQUFFO01BQ1RDLGNBQWMsRUFBRTtRQUNkQyxVQUFVLEVBQUU7VUFDVix3QkFBd0I7WUFDdEJDLGVBQWUsRUFBRTtVQURLLENBRGQ7VUFJVixvQ0FBb0M7WUFDbENBLGVBQWUsRUFBRSxTQURpQixDQUNOOztVQURNLENBSjFCO1VBT1Ysd0JBQXdCO1lBQ3RCQSxlQUFlLEVBQUUsU0FESyxDQUNNOztVQUROLENBUGQ7VUFVVixvQ0FBb0M7WUFDbENBLGVBQWUsRUFBRSxTQURpQixDQUNOOztVQURNO1FBVjFCO01BREU7SUFEUDtFQUREO0FBbEI4QixDQUFELENBQXBDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcmVzdW1lLWJ1aWxkZXIvLi9zcmMvc3R5bGVzL2dsb2JhbC50aGVtZS50cz9hZDlmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZVRoZW1lIH0gZnJvbSAnQG11aS9tYXRlcmlhbC9zdHlsZXMnO1xuXG5leHBvcnQgY29uc3QgR0xPQkFMX01VSV9USEVNRSA9IGNyZWF0ZVRoZW1lKHtcbiAgcGFsZXR0ZToge1xuICAgIHJlc3VtZToge1xuICAgICAgNTA6ICcjRTdFRUZBJyxcbiAgICAgIDEwMDogJyNDN0Q2RTQnLFxuICAgICAgMjAwOiAnI0E4QjlDQycsXG4gICAgICAzMDA6ICcjODg5REIzJyxcbiAgICAgIDQwMDogJyM3MTg4QTEnLFxuICAgICAgNTAwOiAnIzU5NzQ4RicsXG4gICAgICA2MDA6ICcjNEM2NjdFJyxcbiAgICAgIDcwMDogJyMzQzUyNjgnLFxuICAgICAgODAwOiAnIzJFNDA1MicsXG4gICAgICA5MDA6ICcjMUMyQzNBJyxcbiAgICB9LFxuICAgIHByaW1hcnk6IHtcbiAgICAgIG1haW46ICcjMkU0MDUyJyxcbiAgICB9LFxuICB9LFxuICBjb21wb25lbnRzOiB7XG4gICAgTXVpU3dpdGNoOiB7XG4gICAgICBzdHlsZU92ZXJyaWRlczoge1xuICAgICAgICBzd2l0Y2hCYXNlOiB7XG4gICAgICAgICAgJyYgPiAuTXVpU3dpdGNoLXRodW1iJzoge1xuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAnI0ZGRkZGRicsXG4gICAgICAgICAgfSxcbiAgICAgICAgICAnJi5NdWktY2hlY2tlZCA+IC5NdWlTd2l0Y2gtdGh1bWInOiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjNTk3NDhGJywgLy8gcmVzdW1lIDUwMCB2YXJpYW50XG4gICAgICAgICAgfSxcbiAgICAgICAgICAnJiArIC5NdWlTd2l0Y2gtdHJhY2snOiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjQzdENkU0JywgLy8gcmVzdW1lIDEwMCB2YXJpYW50XG4gICAgICAgICAgfSxcbiAgICAgICAgICAnJi5NdWktY2hlY2tlZCArIC5NdWlTd2l0Y2gtdHJhY2snOiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjQzdENkU0JywgLy8gcmVzdW1lIDEwMCB2YXJpYW50XG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn0pO1xuXG5kZWNsYXJlIG1vZHVsZSAnQG11aS9tYXRlcmlhbC9zdHlsZXMnIHtcbiAgaW50ZXJmYWNlIFBhbGV0dGUge1xuICAgIHJlc3VtZTogUGFsZXR0ZVsnZ3JleSddO1xuICB9XG5cbiAgLy8gYWxsb3cgY29uZmlndXJhdGlvbiB1c2luZyBgY3JlYXRlVGhlbWVgXG4gIGludGVyZmFjZSBQYWxldHRlT3B0aW9ucyB7XG4gICAgcmVzdW1lPzogUGFsZXR0ZU9wdGlvbnNbJ2dyZXknXTtcbiAgfVxufVxuIl0sIm5hbWVzIjpbImNyZWF0ZVRoZW1lIiwiR0xPQkFMX01VSV9USEVNRSIsInBhbGV0dGUiLCJyZXN1bWUiLCJwcmltYXJ5IiwibWFpbiIsImNvbXBvbmVudHMiLCJNdWlTd2l0Y2giLCJzdHlsZU92ZXJyaWRlcyIsInN3aXRjaEJhc2UiLCJiYWNrZ3JvdW5kQ29sb3IiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/styles/global.theme.ts\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "@mui/material/styles":
/*!***************************************!*\
  !*** external "@mui/material/styles" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ "@mui/x-date-pickers":
/*!**************************************!*\
  !*** external "@mui/x-date-pickers" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/x-date-pickers");

/***/ }),

/***/ "@mui/x-date-pickers/AdapterDayjs":
/*!***************************************************!*\
  !*** external "@mui/x-date-pickers/AdapterDayjs" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "@vercel/analytics/react":
/*!******************************************!*\
  !*** external "@vercel/analytics/react" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@vercel/analytics/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.tsx"));
module.exports = __webpack_exports__;

})();